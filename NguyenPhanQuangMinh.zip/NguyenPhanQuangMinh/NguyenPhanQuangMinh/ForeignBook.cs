﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NguyenPhanQuangMinh
{
    class ForeignBook : Book
    {
        private string language;
        private int lvlFlag;

        private static int minPrice = 0;

        private static string[] lvlName = { "Basic level", "Intermediate level", "Advanced level" };
        private static int[] lvlVocab = { 400, 1000, 1500 };

        public ForeignBook(string title, string author, int nPage, int purchasePrice, string language, int lvlFlag):
            base(title, author, nPage, purchasePrice)
        {
            this.language = language;
            this.lvlFlag = lvlFlag;
        }

        public override string ToString()
        {
            return base.ToString()
                + "\n\tLanguage: " + language
                + "\n\tDifficulty: " + lvlName[lvlFlag]
                + "\tVocabulary required: " + lvlVocab[lvlFlag] + " words";
        }

        public string Language
        {
            get { return language; }
        }

        public override int SalePrice
        {
            get
            {
                int nwPrice = (int)(base.SalePrice * (1 - lvlVocab[lvlFlag] / 1000f));
                return Math.Max(nwPrice, minPrice);
            }
        }

        public static int MinPrice
        {
            get { return minPrice; }
            set { minPrice = value; }
        }
    }
}
