﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace NguyenPhanQuangMinh
{
    class BookSale
    {
        private string filePath = "books.txt";
        private Random rand = new Random();
        private List<Book> books = new List<Book>();

        public void Start()
        {
            StaticValues();
            ReadFile();
            WriteBook();
            Sales();
            MostExpensive();
            Cheapest();
        }

        private void StaticValues()
        {
            Book.VatPct = 0.1;
            ForeignBook.MinPrice = 100;
        }

        private void ReadFile()
        {
            StreamReader sReader = new StreamReader(filePath);

            string language, author, title;
            int nPage, purchasePrice, lvlFlag;

            while (!sReader.EndOfStream)
            {
                language = sReader.ReadLine();
                author = sReader.ReadLine();
                title = sReader.ReadLine();
                nPage = int.Parse(sReader.ReadLine());
                purchasePrice = int.Parse(sReader.ReadLine());

                if(language == "hungarian")
                {
                    books.Add(new Book(title, author, nPage, purchasePrice));
                }
                else
                {
                    lvlFlag = int.Parse(sReader.ReadLine()) - 1;
                    books.Add(new ForeignBook(title, author, nPage, purchasePrice, language, lvlFlag));
                }
            }
        }

        private void WriteBook()
        {
            Console.WriteLine("\nBooks Information:");
            foreach(Book book in books)
            {
                Console.WriteLine(book);
            }
        }

        private void Sales()
        {
            int totIncome = 0;
            foreach(Book book in books)
            {
                totIncome += book.SalePrice;
            }
            Console.WriteLine("\nTotal income from selling books: " + totIncome);
        }

        private void MostExpensive()
        {
            int mxPrice = int.MinValue;
            foreach(Book book in books)
            {
                if(mxPrice < book.SalePrice)
                {
                    mxPrice = book.SalePrice;
                }
            }

            Console.WriteLine("\nMost expensive book(s):");
            foreach(Book book in books)
            {
                if(mxPrice == book.SalePrice)
                {
                    Console.WriteLine(book);
                }
            }
        }

        private void Cheapest()
        {
            int mnPrice = int.MaxValue;
            foreach (Book book in books)
            {
                if (mnPrice > book.SalePrice)
                {
                    mnPrice = book.SalePrice;
                }
            }

            Console.WriteLine("\nCheapest book(s):");
            foreach (Book book in books)
            {
                if (mnPrice == book.SalePrice)
                {
                    Console.WriteLine(book);
                }
            }
        }
    }
}
