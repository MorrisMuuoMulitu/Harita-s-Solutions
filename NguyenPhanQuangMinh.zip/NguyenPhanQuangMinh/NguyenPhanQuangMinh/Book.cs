﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NguyenPhanQuangMinh
{
    class Book
    {
        private string title;
        private string author;
        private int nPage;
        private int purchasePrice;

        private static double vatPct = 0.27;

        public Book(string title, string author, int nPage, int purchasePrice)
        {
            this.title = title;
            this.author = author;
            this.nPage = nPage;
            this.purchasePrice = purchasePrice;
        }

        public override string ToString()
        {
            return "Book Title: " + title
                + "\tAuthor: " + author
                + "\n\tPage number: " + nPage
                + "\tSale price: " + SalePrice;
        }

        public string Title {
            get { return title; }
        }

        public string Author {
            get { return author; }
        }

        public int PageNumber {
            get { return nPage; }
        }

        private int TAX
        {
            get { return (int)(purchasePrice * vatPct); }
        }

        public virtual int SalePrice
        {
            get { return (int)(purchasePrice * (1 + vatPct)); }
        }

        public static double VatPct {
            get { return vatPct; }
            set { vatPct = value; }
        }
    }
}
